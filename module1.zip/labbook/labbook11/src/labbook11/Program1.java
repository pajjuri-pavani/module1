package labbook11;

public class Program1 
{
String name;
Double salary;
String designation;
public String insuranceScheme;
Program1(String name,Double salary,String designation)
{
	this.name=name;
	this.salary=salary;
	this.designation=designation;
	if(this.salary>5000 && this.salary<20000)
	{
		this.insuranceScheme="Scheme C";
	}
	if(this.salary>=20000 && this.salary<40000)
	{
		this.insuranceScheme="Scheme B";
	}
	else if(this.salary>=40000)
	{
		this.insuranceScheme="Scheme A";
	}
	else if(this.salary<5000)
	{
		insuranceScheme="no Scheme";
	}
}
Program1(String name,Double salary)
{
	this.name=name;
	this.salary=salary;
	//this.designation=designation;
	if(this.salary>5000 && this.salary<20000)
	{
		this.insuranceScheme="Scheme C";
	}
	if(this.salary>=20000 && this.salary<40000)
	{
		this.insuranceScheme="Scheme B";
	}
	else if(this.salary>=40000)
	{
		this.insuranceScheme="Scheme A";
	}
	else if(this.salary<5000)
	{
		insuranceScheme="no Scheme";
	}
}
Program1(Double salary)
{
	//this.name=name;
	this.salary=salary;
	//this.designation=designation;
	if(this.salary>5000 && this.salary<20000)
	{
		this.insuranceScheme="Scheme C";
	}
	if(this.salary>=20000 && this.salary<40000)
	{
		this.insuranceScheme="Scheme B";
	}
	else if(this.salary>=40000)
	{
		this.insuranceScheme="Scheme A";
	}
	else if(this.salary<5000)
	{
		insuranceScheme="no Scheme";
	}
}
public class program1
{
	public void main(String[] args) {
		program1 p=new program1();
	}
}




}
