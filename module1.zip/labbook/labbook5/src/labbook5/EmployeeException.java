package labbook5;
import java.util.Scanner;

@SuppressWarnings("serial")
class InvalidAgeException extends Throwable {
	public InvalidAgeException(String errorMsg) {
		super(errorMsg);
	}
}

public class EmployeeException {
	static void validation(int age) throws InvalidAgeException {
		if (age < 15) {
			throw new InvalidAgeException("Exception thrown for invalid age");
		} else {
			System.out.println("valid age");
		}
	}

	public static void main(String[] args) throws InvalidAgeException {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("enter age");
		EmployeeException.validation(sc.nextInt());

	}

}