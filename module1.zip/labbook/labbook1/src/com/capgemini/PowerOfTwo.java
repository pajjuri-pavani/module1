package com.capgemini;
import java.util.Scanner;
public class PowerOfTwo {
public boolean checkNumber(int n)
{
	boolean result=false;
	while(n>1)
	{
		if(n%2!=0)
		{
			result=false;
			break;
		}
		else
		{
			result=true;
			n/=2;
		}
	}
	return result;
}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		PowerOfTwo power=new PowerOfTwo();
		System.out.println(power.checkNumber(n));
	}
}