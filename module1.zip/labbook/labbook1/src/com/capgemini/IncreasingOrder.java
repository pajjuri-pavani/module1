package com.capgemini;
import java.util.Scanner;
public class IncreasingOrder {
public boolean checkNumber(int n)
{
	boolean result=false;
	while(n>=1)
	{
		int rem1=n%10;
		n/=10;
		int rem2=n%10;
		if(rem2<=rem1)
			result=true;
		else 
			{result=false;
			break;
			}
		rem1=rem2;
	}
	return result;
}
public static void main(String args[])
{
	Scanner sc= new Scanner(System.in);
	int n= sc.nextInt();
	IncreasingOrder in= new IncreasingOrder();
	System.out.println(in.checkNumber(n));
}
}
