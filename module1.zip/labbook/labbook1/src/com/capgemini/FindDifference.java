package com.capgemini;

import java.util.Scanner;

public class FindDifference 
{
	public int calculateDifference(int n)
		{
			int sum=0,sum1=0;
			for(int i=1;i<=n;i++)
			{
				sum+=i*i;
				sum1+=i;
			}
			sum-=sum1*sum1;
			return sum;
		}
		public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();
		FindDifference d= new FindDifference();
		System.out.println(d.calculateDifference(n));
		}

	}


