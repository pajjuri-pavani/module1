package labbook3;
import java.util.Scanner;

public class ReverseNumber {
	int[] getSorted(int a[]){
	int i;
	String b;
	for(i=0;i<a.length;i++){
		b=Integer.toString(a[i]);
		StringBuilder sb=new StringBuilder(b);
		sb.reverse();
		a[i]=Integer.parseInt(sb.toString());
		}	
	int c;
	for (i = 0; i < a.length; i++) {
		for (int j = i + 1; j < a.length; j++) {
			if (a[i] > a[j]) {
				c = a[i];
				a[i] = a[j];
				a[j] = c;
			}
		}
	}
	return a;
	}

	public static void main(String[] args) {
		ReverseNumber e = new ReverseNumber();
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		System.out.println("enter no.of elements in array");
		int n = s.nextInt();
		System.out.println("enter elements into array");
		int[] a = new int[n];// TODO Auto-generated method stub
		for (int k = 0; k < n; k++) {
			a[k] = s.nextInt();
		}
		a=e.getSorted(a);
		for(int i=0;i<a.length;i++){
			System.out.println(a[i]);
			}
	}

}